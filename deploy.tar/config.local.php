<?php
// Lokale Konfiguration fuer dieses System.
// Trage unten deine SMTP-Daten ein und setze SMTP_ENABLED auf '1'.

return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'vocab_app',
    'DB_NAME_FALLBACK' => 'vokabeltrainer',
    'DB_USER' => 'root',
    'DB_PASS' => '',

    // Dev-URL. Falls Vite auf anderem Port laeuft, hier anpassen.
    'APP_BASE_URL' => 'http://localhost:5174',

    'MAIL_FROM_ADDRESS' => 'schneider.xenia@gmail.com',
    'MAIL_FROM_NAME' => 'Vokabeltrainer',

    // Gmail SMTP
    // Wichtig: Hier NICHT dein normales Gmail-Passwort eintragen,
    // sondern ein Google App-Passwort (16 Zeichen).
    'SMTP_ENABLED' => '1',
    'SMTP_HOST' => 'smtp.gmail.com',
    'SMTP_PORT' => 587,
    'SMTP_SECURE' => 'tls',
    'SMTP_USER' => 'schneider.xenia@gmail.com',
    'SMTP_PASS' => 'ihsk pafc cnju asaj', // <-- App-Passwort von Google eintragen (16 Zeichen)
    'SMTP_TIMEOUT_SECONDS' => 15,
    'SMTP_EHLO_HOST' => 'localhost',
];
